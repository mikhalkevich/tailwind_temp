<html>
 <head>
  <title>Название проекта</title>
 </head>
 <body>
 <nav>
  <ul>
   <li><a href="/">Main</a></li>
   <li><a href="/about.php">About</a></li>
   <li><a href="/contact.php">Contact</a></li>
  </ul>
 </nav>