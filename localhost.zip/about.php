<html>
 <head>
  <title>Название проекта</title>
 </head>
 <body>
<?php require_once('templates/top.php')?>
 About<br />
<?php require_once('templates/bottom.php')?>
 </body>
</html>
