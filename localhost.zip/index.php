<?php require_once('templates/top.php')?>
 Middle<br />
<?php require_once('templates/bottom.php')?>
